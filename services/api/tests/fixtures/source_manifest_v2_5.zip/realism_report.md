# Observed-sales realism

Policy: observed-sales-realism-1.1.0. Status: diagnostic.

| Metric | Sample | Value | Threshold | Status |
|---|---:|---|---|---|
| top_20_percent_catalog_revenue_share | 8 | 0.6805793132998363 | {'min': 0.45, 'max': 0.8, 'minimum_sample': 50} | not_evaluable |
| average_distinct_order_items | 160 | 1.775 | {'min': 1.2, 'max': 3.5, 'minimum_sample': 30} | passed |
| open_panel_zero_rate | 72 | 0.20833333333333334 | {'min': 0, 'max': 1} | passed |
| causal_promotion_uplift | 284 | None | None | not_ready |
| stockout_rate | 0 | None | None | not_ready |
| open_panel_zero_rate:core_product/Electronics/online | 3 | 0.0 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| open_panel_zero_rate:core_product/Electronics/store | 6 | 0.0 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| open_panel_zero_rate:core_product/Home Improvement/online | 3 | 0.0 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| open_panel_zero_rate:core_product/Home Improvement/store | 6 | 0.0 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| open_panel_zero_rate:declining_product/Beauty/online | 3 | 0.0 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| open_panel_zero_rate:declining_product/Beauty/store | 6 | 0.0 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| open_panel_zero_rate:declining_product/Sports/online | 3 | 0.0 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| open_panel_zero_rate:declining_product/Sports/store | 6 | 0.0 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| open_panel_zero_rate:long_tail/Pet Care/online | 3 | 0.6666666666666666 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| open_panel_zero_rate:long_tail/Pet Care/store | 6 | 0.8333333333333334 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| open_panel_zero_rate:long_tail/Toys/online | 3 | 0.6666666666666666 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| open_panel_zero_rate:long_tail/Toys/store | 6 | 1.0 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| open_panel_zero_rate:new_product/Fashion/online | 3 | 0.0 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| open_panel_zero_rate:new_product/Fashion/store | 6 | 0.0 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| open_panel_zero_rate:seasonal/Grocery/online | 3 | 0.0 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| open_panel_zero_rate:seasonal/Grocery/store | 6 | 0.0 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| final_refunded_unit_rate:core_product/Electronics/online | 71 | 0.23943661971830985 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:core_product/Electronics/store | 106 | 0.0660377358490566 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:core_product/Home Improvement/online | 75 | 0.17333333333333334 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:core_product/Home Improvement/store | 124 | 0.07258064516129033 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |
| final_refunded_unit_rate:declining_product/Beauty/online | 3 | 0.0 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| final_refunded_unit_rate:declining_product/Beauty/store | 7 | 0.0 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| final_refunded_unit_rate:declining_product/Sports/online | 7 | 0.2857142857142857 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| final_refunded_unit_rate:declining_product/Sports/store | 9 | 0.0 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| final_refunded_unit_rate:long_tail/Pet Care/online | 1 | 0.0 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| final_refunded_unit_rate:long_tail/Pet Care/store | 1 | 0.0 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| final_refunded_unit_rate:long_tail/Toys/online | 1 | 0.0 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| final_refunded_unit_rate:new_product/Fashion/online | 23 | 0.43478260869565216 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| final_refunded_unit_rate:new_product/Fashion/store | 22 | 0.36363636363636365 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| final_refunded_unit_rate:seasonal/Grocery/online | 21 | 0.0 | {'min': 0, 'max': 1, 'minimum_sample': 30} | not_evaluable |
| final_refunded_unit_rate:seasonal/Grocery/store | 33 | 0.030303030303030304 | {'min': 0, 'max': 1, 'minimum_sample': 30} | passed |

Bounded synthetic data is not a production distribution or model benchmark.
