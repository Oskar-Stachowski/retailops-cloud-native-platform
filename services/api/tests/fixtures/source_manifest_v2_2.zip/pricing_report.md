# Source pricing quality

Policy: retail-pricing-1.0.0
Status: passed

| Check | Status | Sample size |
|---|---|---:|
| pricing_schema_versions_scope | passed | 156 |
| known_price_coverage_and_priority | passed | 72 |
| transaction_price_reconciliation | passed | 35 |
| realized_price_aggregates | passed | 29 |
| legacy_pricing_adapter | passed | 50 |
| promotion_truth_direction | passed | 42 |

Realized prices are outcomes. Complete daily panel: false. Inventory ready: false.
