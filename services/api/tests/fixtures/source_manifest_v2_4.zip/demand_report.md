# Daily demand quality

Policy: daily-demand-1.0.0. Status: passed.

| Check | Status | Sample size |
|---|---|---:|
| demand_schema | passed | 144 |
| daily_panel_coverage | passed | 72 |
| daily_transaction_aggregation | passed | 72 |
| basket_sku_totals | passed | 160 |
| daily_demand_budget | passed | 72 |
| daily_source_completeness | passed | 72 |

Valid panel rows: 72; excluded inactive: 0.
Inventory remains not ready; returns are reconciled by retail-returns-1.0.0.
