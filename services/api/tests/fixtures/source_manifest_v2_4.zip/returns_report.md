# Chronology and returns quality

Policy: retail-returns-1.0.0. Status: passed.

| Check | Status | Sample size |
|---|---|---:|
| returns_schema | passed | 233 |
| return_window_policy | passed | 32 |
| transaction_chronology | passed | 284 |
| return_reference_and_window | passed | 57 |
| return_quantity_and_refunds | passed | 57 |
| return_snapshot_reconciliation | passed | 144 |
| return_tail_completeness | passed | 72 |

Return tail: 39 days. History events: 2; tail events: 55.
gross minus refunded amounts known at the explicit cutoff; final only after return-window and ingestion maturity
Inventory remains not ready.
